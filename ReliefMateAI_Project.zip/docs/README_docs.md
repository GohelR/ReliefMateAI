# Documentation

- **architecture-diagram.png**: High-level system flow.
- **Data Policy**: Never store sensitive data beyond what is required during disasters.
- **API Notes**: Planned integration with govt/NGO feeds.
